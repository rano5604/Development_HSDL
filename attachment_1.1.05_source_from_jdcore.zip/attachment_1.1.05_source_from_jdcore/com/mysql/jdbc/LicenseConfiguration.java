package com.mysql.jdbc;

import java.sql.SQLException;
import java.util.Map;

class LicenseConfiguration
{
  static void checkLicenseType(Map<String, String> serverVariables)
    throws SQLException
  {}
  
  private LicenseConfiguration() {}
}
