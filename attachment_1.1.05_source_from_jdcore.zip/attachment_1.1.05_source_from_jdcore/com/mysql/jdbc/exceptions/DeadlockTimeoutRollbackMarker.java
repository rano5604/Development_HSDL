package com.mysql.jdbc.exceptions;

public abstract interface DeadlockTimeoutRollbackMarker {}
