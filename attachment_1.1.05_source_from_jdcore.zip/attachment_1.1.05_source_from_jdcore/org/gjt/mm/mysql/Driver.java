package org.gjt.mm.mysql;

import java.sql.SQLException;

public class Driver
  extends com.mysql.jdbc.Driver
{
  public Driver()
    throws SQLException
  {}
}
